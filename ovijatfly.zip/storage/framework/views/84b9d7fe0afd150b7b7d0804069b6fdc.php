<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Tailwind-css -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google-font -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,400;1,500;1,700&family=Saira+Semi+Condensed:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Font-Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" />

    <link rel="stylesheet" href="https://unpkg.com/@themesberg/flowbite@1.2.0/dist/flowbite.min.css" />

</head>

<body class="font-[Roboto]">
    <header class="bg-[#2f466aff]">
        <nav class="flex justify-between items-center w-11/12 py-2 mx-auto max-w-screen-xl">
            <a href="<?php echo e(route('home')); ?>" class="logo-part">
                <img class="rounded cursor-pointer" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/ovijat-logo.png" alt="">
            </a>
            <div
                class="menu-part md:static absolute md:bg-transparent bg-black md:min-h-fit min-h-[40vh] left-0 top-[-100%] md:w-auto w-full flex items-center px-5">
                <ul class="flex md:flex-row flex-col md:items-center gap-5 text-white">
                    <li><a class="hover:text-gray-400 border-b-2" href="">Flight</a></li>
                    <li><a class="hover:text-gray-500" href="">Hotel</a></li>
                    <li><a class="hover:text-gray-500" href="">Visa</a></li>
                    <li><a class="hover:text-gray-500" href="">Umrah</a></li>
                    <li><a class="hover:text-gray-500" href="">Tours</a></li>
                    <li><a class="hover:text-gray-500" href="">Special Offers</a></li>
                    <li><a class="hover:text-gray-500" href="">Group Flight</a></li>
                    <li><a class="hover:text-gray-500" href="">Blog</a></li>
                </ul>
            </div>
            <div class="account-part flex items-center gap-6">
                <button class="bg-[#a6c1ee] text-white px-5 py-2 rounded-full hover:bg-[#87acec]">Account</button>
                <i onclick="onToggleMenu(this)" class="fa-solid fa-bars text-3xl cursor-pointer md:hidden"></i>
            </div>
        </nav>
    </header>
    <main>
        <section id="hero" class='bg-cover pb-6' style="background-image: url('/images/basic/OTA Dextop-CP (1).png')">
            <div id="search-main-part" class="pt-20 max-w-screen-md xl:max-w-screen-xl mx-auto">
                <div id="search-main"
                    class="relative flex flex-col w-full mx-auto items-center bg-white rounded-xl w-100 border-solid border-2 border-[#6f3c07]">
                    <div id="search-option-btn" class="flex gap-3 py-3 mt-10">
                        <button
                            class="rounded-md px-3 py-1 border-solid border-1 border-[#595959] bg-[#e3951fff] text-white">One
                            Way</button>
                        <button
                            class="rounded-md px-3 py-1 border-solid border-1 border-[#595959] bg-[#e3951fff] text-white">Round
                            Trip</button>
                        <button
                            class="rounded-md px-3 py-1 border-solid border-1 border-[#595959] bg-[#e3951fff] text-white">Multy
                            City</button>
                    </div>
                    <div id="search-option-field"
                        class="w-11/12 flex mb-10 rounded-xl border-solid border-2 border-[#595959]">
                        <div
                            class="input-group relative border-solid border-r-2 border-[#595959] flex flex-col lg:w-1/4 p-1 px-2">
                            <label class="uppercase text-sm font-normal" for="">From</label>
                            <p class="text-xl font-bold">Dhaka</p>
                            <p class="text-xs"><span class="font-bold uppercase">Dac</span> Zia International</p>

                            <div id="from-to-icon"
                                class="absolute top-1/2 -right-8 -translate-y-1/2 -translate-x-1/2 drop-shadow-xl w-8 h-8 flex items-center justify-center rounded-full border-solid border-2 border-[#595959] bg-white text-sm">
                                <i class="fa-solid fa-right-left"></i>
                            </div>
                        </div>
                        <div
                            class="input-group flex flex-col border-solid border-r-2 border-[#595959] lg:w-1/4 p-1 px-2 pl-5">
                            <label class="uppercase text-sm font-normal" for="">To</label>
                            <p class="text-xl font-bold">Dubai</p>
                            <p class="text-xs"><span class="font-bold uppercase">Dac</span> Zia International</p>
                        </div>
                        <div class="search-departure-return-date flex lg:w-2/4 border-solid border-r-2 border-[#595959] ">
                            <div
                                class="input-group flex flex-col py-1 px-2 border-solid border-r-2 border-[#595959] lg:w-2/4">
                                <label class="uppercase text-sm font-normal" for="">DEPARTURE</label>
                                <p class="font-medium uppercase"><span class="font-bold pr-2 text-2xl">27</span>Dec"22</p>
                                <p class="text-xs font-bold">Sunday</p>
                            </div>
                            <div
                                class="input-group border-solid flex flex-col py-1 px-2 lg:w-2/4">
                                <label class="uppercase text-sm font-normal" for="">RETURN</label>
                                <p class="text-sm">Tap to add a return date for bigger Discount</p>
                            </div>
                        </div>
                        <div class="input-group flex flex-col py-1 px-2 lg:w-1/4">
                            <label class="uppercase text-sm font-normal" for="">TRAVELLERS & CLASS</label>
                            <p class="font-medium"><span class="font-bold text-2xl">1 </span>Traveller</p>
                            <p class="text-sm">Economy/Premium Economy</p>
                        </div>
                    </div>
                    <div id="search-taps"
                        class="absolute lg:w-6/12 -top-9 flex gap-3 px-3 py-1 bg-white justify-between items-center text-center rounded-xl border-solid border-2 border-[#595959]">
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/flight.png" alt="Flight">
                                <p class="text-sm">Flight</p>
                            </a>
                        </div>
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/hotel.png" alt="Hotel">
                                <p class="text-sm">Hotel</p>
                            </a>
                        </div>
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="<?php echo e(route('umrah')); ?>" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/umrah.png" alt="Umrah">
                                <p class="text-sm">Umrah</p>
                            </a>
                        </div>
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/tour.png" alt="Tours">
                                <p class="text-sm">Tours</p>
                            </a>
                        </div>
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/visa.png" alt="Visa">
                                <p class="text-sm">Visa</p>
                            </a>
                        </div>
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/group.png" alt="Group Fare">
                                <p class="text-sm">Group Fare</p>
                            </a>
                        </div>
                        <div class="tap-group flex flex-col items-center text-center w-full">
                            <a href="" class="hover:text-blue-400">
                                <img class='w-10' src="<?php echo e(asset('frontend/asset')); ?>/images/basic/car.png" alt="Car Pental">
                                <p class="text-sm">Car Pental</p>
                            </a>
                        </div>
                    </div>
                    <div id="search-button" class="absolute -bottom-4">
                        <button
                            class="bg-[#3c78d8ff] rounded-xl border-solid border-2 border-[#ffffff] text-white py-1 px-6">Search</button>
                    </div>
                </div>
            </div>
            <div id="tracking-area"
                class="flex w-full bg-white mx-auto mt-14 rounded-full border-solid border-2 border-[#ff9900] max-w-screen-md xl:max-w-screen-xl">
                <div class="track-group w-full p-2 flex items-center border-solid border-r-2 border-[#595959]">
                    <p class="text-xs text-center w-full">Explore Amazing Offers</p>
                </div>
                <div class="track-group w-full p-2 flex items-center border-solid border-r-2 border-[#595959]">
                    <p class="text-xs text-center w-full">Track Hotel Book Status</p>
                </div>
                <div class="track-group w-full p-2  flex items-center border-solid border-r-2 border-[#595959]">
                    <p class="text-xs text-center w-full">Track Visa Application Status</p>
                </div>
                <div class="track-group w-full p-2  flex items-center border-solid border-r-2 border-[#595959]">
                    <p class="text-xs text-center w-full">Track Umrah Book Status</p>
                </div>
                <div class="track-group w-full p-2  flex items-center">
                    <p class="text-xs text-center w-full">Track Flight Book Status</p>
                </div>
            </div>
        </section>
        <section id="separator"
            class="bg-[#4285f4ff] my-5 max-w-screen-md xl:max-w-screen-xl mx-auto shadow rounded-md">
            <div class="package-title-area flex gap-3 justify-center items-center py-1">
                <img class="w-9" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/tour-package-logo.png" alt="">
                <h2 class="text-md font-bold text-white">LATEST TOUR PACKAGES</h2>
                <img class="w-9" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/tour-package-logo.png" alt="">
            </div>
        </section>
        <section id="offer-slider-area"
            class="grid gap-4 grid-cols-2 md:grid-cols-3 max-w-screen-md xl:max-w-screen-xl bg-white shadow mx-auto w-full p-4 rounded-md">
            <div class="offer-group flex w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-full">
                <div class="offer-banner w-full">
                    <img class="rounded-t-lg w-40 h-40" src="<?php echo e(asset('frontend/asset')); ?>/images/offers/picture1.png" alt="">
                </div>
                <div class="offer-short-desc p-2 text-center w-full flex flex-col my-auto">
                    <h2 class="text-lg font-bold">This is offer Title</h2>
                    <p class="text-sm">This is offer short description</p>
                </div>
            </div>
            <div class="offer-group flex w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-full">
                <div class="offer-banner w-full">
                    <img class="rounded-t-lg w-40 h-40" src="<?php echo e(asset('frontend/asset')); ?>/images/offers/picture1.png" alt="">
                </div>
                <div class="offer-short-desc p-2 text-center w-full flex flex-col my-auto">
                    <h2 class="text-lg font-bold">This is offer Title</h2>
                    <p class="text-sm">This is offer short description</p>
                </div>
            </div>
            <div class="offer-group flex w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-full">
                <div class="offer-banner w-full">
                    <img class="rounded-t-lg w-40 h-40" src="<?php echo e(asset('frontend/asset')); ?>/images/offers/picture1.png" alt="">
                </div>
                <div class="offer-short-desc p-2 text-center w-full flex flex-col my-auto">
                    <h2 class="text-lg font-bold">This is offer Title</h2>
                    <p class="text-sm">This is offer short description</p>
                </div>
            </div>
        </section>
        <section id="separator"
            class="bg-[#4285f4ff] my-5 max-w-screen-md xl:max-w-screen-xl mx-auto shadow rounded-md">
            <div class="package-title-area flex gap-3 justify-center items-center py-1">
                <img class="w-9" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/tour-package-logo.png" alt="">
                <h2 class="text-md font-bold text-white">LATEST TOUR PACKAGES</h2>
                <img class="w-9" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/tour-package-logo.png" alt="">
            </div>
        </section>
        <section id="tour-package-area"
            class="grid gap-3 grid-cols-1 grid-cols-2 md:grid-cols-3 lg:grid-cols-4 max-w-screen-md xl:max-w-screen-xl bg-white shadow mx-auto w-full p-4 rounded-md">
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <div class="package-banner w-full h-3/4">
                    <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/tour-packages/tour-package.png" alt="">
                </div>
                <div class="package-body">
                    <div class="package-short-desc p-2">
                        <h3 class="text-sm font-bold">This is package</h3>
                    </div>
                    <div class="package-price-duration flex justify-between">
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                    </div>
                </div>
            </div>
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <div class="package-banner w-full h-3/4">
                    <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/tour-packages/tour-package.png" alt="">
                </div>
                <div class="package-body">
                    <div class="package-short-desc p-2">
                        <h3 class="text-sm font-bold">This is package</h3>
                    </div>
                    <div class="package-price-duration flex justify-between">
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                    </div>
                </div>
            </div>
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <div class="package-banner w-full h-3/4">
                    <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/tour-packages/tour-package.png" alt="">
                </div>
                <div class="package-body">
                    <div class="package-short-desc p-2">
                        <h3 class="text-sm font-bold">This is package</h3>
                    </div>
                    <div class="package-price-duration flex justify-between">
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                    </div>
                </div>
            </div>
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <div class="package-banner w-full h-3/4">
                    <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/tour-packages/tour-package.png" alt="">
                </div>
                <div class="package-body">
                    <div class="package-short-desc p-2">
                        <h3 class="text-sm font-bold">This is package</h3>
                    </div>
                    <div class="package-price-duration flex justify-between">
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                        <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                    </div>
                </div>
            </div>
        </section>
        <section id="separator"
            class="bg-[#f9b660ff] my-5 max-w-screen-md xl:max-w-screen-xl mx-auto shadow rounded-md">
            <div class="package-title-area flex gap-3 justify-center items-center py-1">
                <img class="w-9" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/umrah-logo.png" alt="">
                <h2 class="text-md font-bold text-black">UMRAH PACKAGES</h2>
                <img class="w-9" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/umrah-logo.png" alt="">
            </div>
        </section>
        <section id="umrah-package-area"
            class="grid gap-4 grid-cols-1 grid-cols-2 md:grid-cols-3 lg:grid-cols-4 max-w-screen-md xl:max-w-screen-xl bg-white shadow mx-auto w-full p-4 rounded-md">
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <a href="<?php echo e(route('umrah.details')); ?>" class="">
                    <div class="package-banner w-full h-3/4">
                        <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/umrah-packages/umrah-package.png" alt="">
                    </div>
                    <div class="package-body">
                        <div class="package-short-desc p-2">
                            <h3 class="text-sm font-bold">This is package</h3>
                        </div>
                        <div class="package-price-duration flex justify-between">
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <a href="<?php echo e(route('umrah.details')); ?>" class="">
                    <div class="package-banner w-full h-3/4">
                        <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/umrah-packages/umrah-package.png" alt="">
                    </div>
                    <div class="package-body">
                        <div class="package-short-desc p-2">
                            <h3 class="text-sm font-bold">This is package</h3>
                        </div>
                        <div class="package-price-duration flex justify-between">
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <a href="<?php echo e(route('umrah.details')); ?>" class="">
                    <div class="package-banner w-full h-3/4">
                        <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/umrah-packages/umrah-package.png" alt="">
                    </div>
                    <div class="package-body">
                        <div class="package-short-desc p-2">
                            <h3 class="text-sm font-bold">This is package</h3>
                        </div>
                        <div class="package-price-duration flex justify-between">
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="package-card w-full bg-gray-200 rounded-lg border-solid border-1 border-[#ff9900] shadow h-80">
                <a href="<?php echo e(route('umrah.details')); ?>" class="">
                    <div class="package-banner w-full h-3/4">
                        <img class="rounded-t-lg w-full h-full" src="<?php echo e(asset('frontend/asset')); ?>/images/umrah-packages/umrah-package.png" alt="">
                    </div>
                    <div class="package-body">
                        <div class="package-short-desc p-2">
                            <h3 class="text-sm font-bold">This is package</h3>
                        </div>
                        <div class="package-price-duration flex justify-between">
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">6 Nights/7 Days</p>
                            <p class="bg-indigo-900 text-white text-xs rounded-md p-1">5000 BDT/per-person</p>
                        </div>
                    </div>
                </a>
            </div>
        </section>
    </main>
    <footer class="bg-[#2f466a] mt-5">
        <div id="top-footer-area" class="grid grid-cols-4 gap-2 mx-auto max-w-screen-md xl:max-w-screen-xl p-4 py-6">
            <div class="footer-coloum text-white">
                <div class="footer-coloum-header">
                    <h3 class="uppercase font-bold text-sm pb-2">About Us</h3>
                </div>
                <div class="footer-coloum-link flex flex-col gap-y-1">
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>About us</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Career</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Community</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Relationship</a>
                </div>
            </div>
            <div class="footer-coloum text-white">
                <div class="footer-coloum-header">
                    <h3 class="uppercase font-bold text-sm pb-2">Contact Us</h3>
                </div>
                <div class="footer-coloum-link flex flex-col gap-y-1">
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Rokeya Mansion,
                        Naya Paltan, Dhaka-1000.</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>+880 1722
                        157417</a>
                    <a href="" class="text-xs"><i
                            class="fa-solid fa-location-arrow rotate-45 mr-2"></i>ovijatfly@gmail.com</a>
                </div>
            </div>
            <div class="footer-coloum text-white">
                <div class="footer-coloum-header">
                    <h3 class="uppercase font-bold text-sm pb-2">Help & Contact</h3>
                </div>
                <div class="footer-coloum-link flex flex-col gap-y-1">
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Terms &
                        Conditions</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Payment
                        Method</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Refund
                        Policy</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Privacy
                        Policy</a>
                </div>
            </div>
            <div class="footer-coloum text-white">
                <div class="footer-coloum-header">
                    <h3 class="uppercase font-bold text-sm pb-2">News & Media</h3>
                </div>
                <div class="footer-coloum-link flex flex-col gap-y-1">
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Facebook</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Instagram</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Twitter</a>
                    <a href="" class="text-xs"><i class="fa-solid fa-location-arrow rotate-45 mr-2"></i>Linkedin</a>
                </div>
            </div>
        </div>
        <hr class="top-footer-divider border-2 border-[#ff9900]" />
        <div id="middle-footer-area" class="grid grid-cols-3 py-6 gap-2 mx-auto max-w-screen-md xl:max-w-screen-xl">
            <div class="left-area flex flex-col">
                <div class="w-full">
                    <fieldset class="border-t-4 border-slate-300">
                        <legend class="mx-auto px-4 text-white text-lg uppercase font-bold">We Accept</legend>
                    </fieldset>
                </div>
                <img class="w-full" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/left-picture.png" alt="">
            </div>
            <div class="middle-area w-full flex flex-col items-center">
                <div class="bg-green-400 rounded-full w-[50%] h-[75%] relative">
                    <img class="w-28 absolute absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rounded-lg"
                        src="<?php echo e(asset('frontend/asset')); ?>/images/basic/ovijat-logo.png" alt="">
                </div>
                <div class="bg-blue-700 mt-3">
                    <p class="px-3 py-1 font-bold rounded-lg text-[#facc15]">OvijatFly.com</p>
                </div>
            </div>
            <div class="right-area">
                <div class="w-full">
                    <fieldset class="border-t-4 border-slate-300">
                        <legend class="mx-auto px-4 text-white text-lg uppercase font-bold">Certification</legend>
                    </fieldset>
                </div>
                <img class="w-full" src="<?php echo e(asset('frontend/asset')); ?>/images/basic/right-picture.png" alt="">
            </div>
        </div>
        <hr class="top-footer-divider" />
        <div id="button-footer-area"
            class="text-white flex justify-between mx-auto max-w-screen-md xl:max-w-screen-xl py-4">
            <div id="copyright-area">
                <p class="text-sm">Copyright&copy;
                    <script>document.write(new Date().getFullYear());</script> - All rights reserved by OvijatTravels
                </p>
            </div>
            <div id="developer-area">
                <p class="text-sm">Developed by Shahabuddin</p>
            </div>
        </div>
    </footer>
    <script>
        function onToggleMenu(element) {
            const navLink = document.querySelector('.menu-part');
            if (element.classList.contains('fa-bars')) {
                element.classList.remove('fa-bars');
                element.classList.add('fa-xmark');
            } else {
                element.classList.add('fa-bars');
                element.classList.remove('fa-xmark');
            }
            navLink.classList.toggle('top-[6%]');
        }
    </script>
<!-- Code injected by live-server -->
<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>

</html><?php /**PATH C:\Users\saika\OneDrive\Desktop\webhouse\ovijatfly\resources\views/welcome.blade.php ENDPATH**/ ?>